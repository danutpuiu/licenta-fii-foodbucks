﻿using System;

namespace WebApp.DTO
{
    public class PriceInfoDTO
    {
        public String StoreName { get; set; }
        public double Price { get; set; }
    }
}
